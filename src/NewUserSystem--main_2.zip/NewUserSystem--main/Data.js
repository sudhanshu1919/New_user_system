export const userList = [
  {
    id: 1,
    name: "Sudhanshu Gaikwad",
    email: "sudhanshugaikwad517@gmail.com",
  },
  {
    id: 2,
    name: "Anuj Gaikwad",
    email: "anujgaikwad@gmail.com",
  },
  {
    id: 3,
    name: "Rajesh Maramplle",
    email: "rajesgmaramplle@gmail.com",
  },
];
