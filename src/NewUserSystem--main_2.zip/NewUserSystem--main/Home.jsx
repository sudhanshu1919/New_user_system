import React from "react";
import Details from "./Details";
function Home() {
  return (
    <div>
      <Details />
    </div>
  );
}

export default Home;
