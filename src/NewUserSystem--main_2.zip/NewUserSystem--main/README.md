# New User System By using Redux Toolkit 
 It includes a create new user system.
 The project replicates the core features of List Of users.
 The List of Users project is a Redux js web app that replicates the core features of the List of Users.
 React, Redux, Html, CSS, Bootstrap
 <h6>New User System </h6>
 <h4>Live Demo <a href=""> New User System</a> </h4>
<img src="https://github.com/sudhanshu1313/NewUserSystem-/blob/main/NewUserSystem01.png" alt="New User System" width="600" height="350px">

<h6> Data File </h6>
<img src="https://github.com/sudhanshu1313/NewUserSystem-/blob/main/NewUserSystemData.png" alt="New User System" width="400" height="300px">



![Demo GIF](https://github.com/sudhanshu1313/NewUserSystem-/blob/main/List%20of%20Users.gif)
